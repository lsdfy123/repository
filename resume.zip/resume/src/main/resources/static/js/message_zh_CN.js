﻿var Message = {
    delete_success : '删除成功！',
    delete_fail : '删除失败！',
    save_success : '保存成功！',
    save_fail : '保存失败！',
    send_success : '发送成功！',
    send_fail : '发送失败！',
    avatar_upload_success : '头像上传成功！',
    avatar_upload_fail : '头像上传失败！',
    resume_upload_success : '简历上传成功！',
    resume_upload_fail : '简历上传失败！',
    is_confirm_delete : '是否确定删除?',
    file_type : '文件类型',
    file_size : '文件大小',
    paging_first : '首页',
    paging_prev : '上一页',
    paging_next : '下一页',
    paging_last : '尾页'
};