﻿var Message = {
    delete_success : 'delete successfully！',
    delete_fail : 'delete fail！',
    save_success : 'save successfully！',
    save_fail : 'save fail！',
    send_success : 'send successfully！',
    send_fail : 'send fail！',
    avatar_upload_success : 'upload avatar successfully！',
    avatar_upload_fail : 'uplaod avatar fail！',
    resume_upload_success : 'upload resume successfully！',
    resume_upload_fail : 'uplaod resume fail！',
    is_confirm_delete : 'do you confirm to delete?',
    file_type : 'File Type',
    file_size : 'File Size',
    paging_first : 'First',
    paging_prev : 'Previous',
    paging_next : 'Next',
    paging_last : 'Last'
};