/*****************************************************************************
 * Copyright (c) 2018, shixun.online
 *
 * All rights reserved
 *
*****************************************************************************/
package online.shixun.project.utils;

import java.io.Serializable;

/**
 * 异步请求响应对象
 */
public class ResponseData implements Serializable {

	private static final long serialVersionUID = 2469337078882712042L;

	
	private static final String SUCCESS_CODE = "0";

    private static final String ERROR_CODE = "-1";

    private String status = SUCCESS_CODE;

    private Object data;

    public boolean isSuccess() {
        return this.status.equalsIgnoreCase(SUCCESS_CODE) ? true : false;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public void setError(Object data) {
        this.status = ERROR_CODE;
        this.data = data;
    }

    public void setError(String status, Object data) {
        this.status = status;
        this.data = data;
    }
}
